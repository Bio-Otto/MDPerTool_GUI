import sys


def main(argv):
    print("GUI APP WILL COME HERE")

if __name__ == '__main__':
    sys.exit(main())
